// базовый пример
document.documentElement.classList.add('js');

/* Modules */
import './modules/dark-light-theme-detection';
import './header-ui';