# Changelog

Track notable documentation updates and icon-system changes here. Follow [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) conventions and date entries using ISO format.

## [Unreleased]

### Added
- Initial documentation scaffold covering overview, icon system, ACF fields, icon sources, recipes, and troubleshooting.

### Changed
- _Nothing yet._

### Fixed
- _Nothing yet._

### Removed
- _Nothing yet._
